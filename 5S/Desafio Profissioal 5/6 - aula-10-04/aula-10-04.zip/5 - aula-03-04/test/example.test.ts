test('deve somar 2 + 2', () => {
    expect (2 + 2).toBe(4)
})