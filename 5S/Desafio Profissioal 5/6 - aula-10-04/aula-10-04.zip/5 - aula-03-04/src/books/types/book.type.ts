export interface BookType {
    title: String
    author: String
    ISBN: String
    price: Number
}